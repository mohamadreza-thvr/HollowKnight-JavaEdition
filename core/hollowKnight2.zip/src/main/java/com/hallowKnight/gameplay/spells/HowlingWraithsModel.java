package com.hallowKnight.gameplay.spells;

import com.badlogic.gdx.math.Rectangle;
import com.hallowKnight.gameplay.enemy.EnemyModel;

import java.util.ArrayList;
import java.util.List;

public class HowlingWraithsModel {
    private float x, y;
    private Rectangle bounds;
    private boolean active = true;
    private float stateTime = 0f;
    private int currentHitTick = 0;

    // لیستی از دشمنان برای هر تیکِ دمیج
    private List<EnemyModel> hitEnemiesThisTick = new ArrayList<>();

    public HowlingWraithsModel(float knightX, float knightY, float knightWidth, float knightHeight) {
        // ابعاد بزرگ و وسیع برای پوشش دادن گوشه‌های بالا
        float width = 220f;
        float height = 260f;

        // تنظیم موقعیت دقیقاً وسط و بالای سر شوالیه
        this.x = knightX + (knightWidth - width) / 2f;
        this.y = knightY + knightHeight - 30f;
        this.bounds = new Rectangle(x, y, width, height);
    }

    public void update(float delta) {
        if (!active) return;
        stateTime += delta;

        // ۱۳ فریم ضربدر 0.05 میشه 0.65 ثانیه عمر کل جادو
        if (stateTime >= 0.65f) {
            active = false;
        }

        // تقسیم کردن 0.65 ثانیه به 3 بخش مساوی برای وارد کردن 3 ضربه متوالی
        int expectedTick = (int)(stateTime / 0.216f);
        if (expectedTick > currentHitTick) {
            currentHitTick = expectedTick;
            // ⚠️ پاک کردن لیست، تا دشمنان بتونن ضربه دوم و سوم رو هم بخورن!
            hitEnemiesThisTick.clear();
        }
    }

    public boolean hasHit(EnemyModel enemy) { return hitEnemiesThisTick.contains(enemy); }
    public void addHitEnemy(EnemyModel enemy) { hitEnemiesThisTick.add(enemy); }

    public boolean isActive() { return active; }
    public void setActive(boolean active) {this.active = active;}

    public Rectangle getBounds() { return bounds; }
    public float getStateTime() { return stateTime; }
    public float getX() { return x; }
    public float getY() { return y; }
}

