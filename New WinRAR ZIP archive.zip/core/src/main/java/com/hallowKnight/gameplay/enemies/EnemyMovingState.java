package com.hallowKnight.gameplay.enemies;

public enum EnemyMovingState {
    WALK,
    IDLE,
    ANTICIPATE,
    DASH,
    TURN
}
