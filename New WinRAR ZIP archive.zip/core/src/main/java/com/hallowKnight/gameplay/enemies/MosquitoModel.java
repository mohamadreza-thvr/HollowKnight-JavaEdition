package com.hallowKnight.gameplay.enemies;

import com.badlogic.gdx.math.Vector2;

public class MosquitoModel extends EnemyModel {

    private EnemyMovingState currentState = EnemyMovingState.IDLE;
    private float stateTimer = 0f;

    private boolean hasAggro = false;
    private Vector2 targetPosition;

    public MosquitoModel(float x, float y) {
        super(x, y, 50, 50, 3);
        this.targetPosition = new Vector2();
    }

    public EnemyMovingState getCurrentState() { return currentState; }
    public void setCurrentState(EnemyMovingState state) { this.currentState = state; }
    public float getStateTimer() { return stateTimer; }
    public void setStateTimer(float timer) { this.stateTimer = timer; }
    public boolean isHasAggro() { return hasAggro; }
    public void setHasAggro(boolean hasAggro) { this.hasAggro = hasAggro; }
    public Vector2 getTargetPosition() { return targetPosition; }
}
