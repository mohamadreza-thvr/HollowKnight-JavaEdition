package com.hallowKnight.gameplay.core;

import com.badlogic.gdx.Game;
import com.hallowKnight.gameplay.knight.KnightController;
import com.hallowKnight.gameplay.enemies.EnemyController; // ⚠️ ایمپورت اضافه شد

public class GameController {
    private Game game;
    private GameModel model;
    private KnightController knightController;

    // ⚠️ کنترلر دشمنان اضافه شد
    private EnemyController enemyController;

    public GameController(GameModel model, Game game) {
        this.game = game;
        this.model = model;
        this.knightController = new KnightController(model.getKnightModel(), model.getCurrentMap(), game);

        // ساخت کنترلر دشمنان
        this.enemyController = new EnemyController();
    }

    public void update(float delta) {
        // ۱. اول آپدیت هوش مصنوعی و حرکت دشمنان
        enemyController.updateEnemies(model.getEnemies(), delta, model.getCurrentMap(), model.getKnightModel());

        // ۲. سپس آپدیت حرکت و ضربات شوالیه
        knightController.update(delta, model.getEnemies());
    }
}
