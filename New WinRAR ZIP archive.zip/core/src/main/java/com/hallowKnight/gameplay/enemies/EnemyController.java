package com.hallowKnight.gameplay.enemies;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.hallowKnight.Constance;
import com.hallowKnight.gameplay.knight.KnightModel;
import com.hallowKnight.gameplay.map.MapModel;

import java.util.List;

public class EnemyController {

    public void updateEnemies(List<EnemyModel> enemies, float delta, MapModel mapModel, KnightModel knight) {
        for (EnemyModel enemy : enemies) {

            // --- مدیریت پرت شدن به عقب (Knockback) ---
            if (enemy.isKnockedBack()) {
                enemy.setKnockbackTimer(enemy.getKnockbackTimer() - delta);
                if (enemy.getKnockbackTimer() <= 0) {
                    enemy.setKnockedBack(false);
                }
            }

            // --- اعمال هوش مصنوعی بر اساس نوع دشمن ---
            if (!enemy.isDead() && !enemy.isKnockedBack()) {
                if (enemy instanceof CrawlidModel) {
                    updateCrawlid((CrawlidModel) enemy, delta, mapModel);
                } else if (enemy instanceof MosquitoModel) {
                    updateMosquito((MosquitoModel) enemy, delta, knight, mapModel);
                }
            }

            // --- اعمال فیزیک مشترک (جاذبه و برخورد با دیوارها) ---
            applyPhysics(enemy, delta, mapModel);
        }
    }
    private void updateCrawlid(CrawlidModel crawlid, float delta, MapModel mapModel) {
        if (crawlid.getCurrentState() == EnemyMovingState.TURN) {
            crawlid.setVelocityX(0);
            crawlid.setStateTimer(crawlid.getStateTimer() + delta);
            // 2 فریم انیمیشن Turn (مثلا 0.2 ثانیه)
            if (crawlid.getStateTimer() > 0.2f) {
                crawlid.setFacingRight(!crawlid.isFacingRight());
                crawlid.setCurrentState(EnemyMovingState.WALK);
            }
            return;
        }

        // حرکت عادی به سمت جلو
        float speed = 100f;
        crawlid.setVelocityX(crawlid.isFacingRight() ? speed : -speed);

        // تشخیص رسیدن به لبه پرتگاه (Edge Detection)
        // یک مستطیل کوچک جلوی پای دشمن می‌سازیم
        float checkX = crawlid.isFacingRight() ? crawlid.getX() + crawlid.getBounds().width : crawlid.getX() - 5f;
        Rectangle edgeChecker = new Rectangle(checkX, crawlid.getY() - 5f, 5f, 5f);

        boolean isGroundAhead = false;
        for (Rectangle solid : mapModel.getSolidBounds()) {
            if (edgeChecker.overlaps(solid)) {
                isGroundAhead = true;
                break;
            }
        }

        // اگر زمین تمام شد، تغییر مسیر بده
        if (!isGroundAhead && crawlid.getVelocityY() == 0) {
            crawlid.setCurrentState(EnemyMovingState.TURN);
            crawlid.setStateTimer(0f);
        }
    }

    private void updateMosquito(MosquitoModel mosquito, float delta, KnightModel knight, MapModel mapModel) {
        // فاصله پشه تا شوالیه
        float distance = Vector2.dst(mosquito.getX(), mosquito.getY(), knight.getX(), knight.getY());

        // اگر شوالیه وارد شعاع 400 پیکسلی شد، برای همیشه قفل می‌شود
        if (!mosquito.isHasAggro() && distance < 400f) {
            mosquito.setHasAggro(true);
        }

        if (mosquito.getCurrentState() == EnemyMovingState.IDLE) {
            mosquito.setVelocityX(0);
            mosquito.setVelocityY(0); // معلق در هوا
            mosquito.setFacingRight(knight.getX() > mosquito.getX());

            if (mosquito.isHasAggro()) {
                // ثبت موقعیت فعلی شوالیه و رفتن به حالت انتظار
                mosquito.getTargetPosition().set(knight.getX(), knight.getY());
                mosquito.setCurrentState(EnemyMovingState.ANTICIPATE);
                mosquito.setStateTimer(0f);
            }
        }
        else if (mosquito.getCurrentState() == EnemyMovingState.ANTICIPATE) {
            mosquito.setStateTimer(mosquito.getStateTimer() + delta);
            // 6 فریم مکث (مثلا 0.6 ثانیه)
            if (mosquito.getStateTimer() >= 0.6f) {
                mosquito.setCurrentState(EnemyMovingState.DASH);
                mosquito.setStateTimer(0f);

                // محاسبه بردار سرعت برای شیرجه به سمت هدف ثبت شده
                Vector2 direction = new Vector2(mosquito.getTargetPosition().x - mosquito.getX(),
                    mosquito.getTargetPosition().y - mosquito.getY());
                direction.nor(); // نرمال‌سازی بردار (جهت خالص)

                float dashSpeed = 450f;
                mosquito.setVelocityX(direction.x * dashSpeed);
                mosquito.setVelocityY(direction.y * dashSpeed);
            }
        }
        else if (mosquito.getCurrentState() == EnemyMovingState.DASH) {
            mosquito.setStateTimer(mosquito.getStateTimer() + delta);

            // توقف شیرجه در صورت گذشتن زمان (مثلا 1 ثانیه) یا برخورد به دیوار
            if (mosquito.getStateTimer() >= 1.0f || mosquito.getVelocityX() == 0 || mosquito.getVelocityY() == 0) {
                mosquito.setCurrentState(EnemyMovingState.IDLE);
                mosquito.setVelocityX(0);
                mosquito.setVelocityY(0);
            }
        }
    }

    private void applyPhysics(EnemyModel enemy, float delta, MapModel mapModel) {
        // حرکت افقی
        enemy.setX(enemy.getX() + (enemy.getVelocityX() * delta));
        enemy.updateBounds();

        boolean hitWall = false;
        for (Rectangle solid : mapModel.getSolidBounds()) {
            if (enemy.getBounds().overlaps(solid)) {
                if (enemy.getVelocityX() > 0) {
                    enemy.setX(solid.x - enemy.getBounds().width);
                } else if (enemy.getVelocityX() < 0) {
                    enemy.setX(solid.x + solid.width);
                }
                enemy.setVelocityX(0);
                enemy.updateBounds();
                hitWall = true;
            }
        }

        // اگر Crawlid به دیوار خورد، بچرخد
        if (hitWall && enemy instanceof CrawlidModel && !enemy.isDead() && !enemy.isKnockedBack()) {
            ((CrawlidModel) enemy).setCurrentState(EnemyMovingState.TURN);
            ((CrawlidModel) enemy).setStateTimer(0f);
        }

        // جاذبه (فقط برای Crawlid یا وقتی دشمنان مرده‌اند/پرت شده‌اند اعمال می‌شود)
        if (enemy instanceof CrawlidModel || enemy.isDead() || enemy.isKnockedBack()) {
            enemy.setVelocityY(enemy.getVelocityY() - (Constance.GRAVITY * delta));
        }

        // حرکت عمودی
        enemy.setY(enemy.getY() + (enemy.getVelocityY() * delta));
        enemy.updateBounds();

        for (Rectangle solid : mapModel.getSolidBounds()) {
            if (enemy.getBounds().overlaps(solid)) {
                if (enemy.getVelocityY() < 0) { // برخورد با زمین
                    enemy.setY(solid.y + solid.height);

                    if (enemy.isDead() && !enemy.isHitGroundAfterDeath()) {
                        enemy.setHitGroundAfterDeath(true); // برای تغییر انیمیشن مرگ در هوا به مرگ روی زمین
                        enemy.setVelocityX(0); // متوقف شدن جسد روی زمین
                    }
                } else if (enemy.getVelocityY() > 0) { // برخورد با سقف
                    enemy.setY(solid.y - enemy.getBounds().height);
                }
                enemy.setVelocityY(0);
                enemy.updateBounds();
            }
        }
    }
}
