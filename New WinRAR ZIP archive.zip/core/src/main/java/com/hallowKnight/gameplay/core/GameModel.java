package com.hallowKnight.gameplay.core;

import com.badlogic.gdx.math.Vector2;
import com.hallowKnight.gameplay.knight.KnightModel;
import com.hallowKnight.gameplay.map.MapModel;
import com.hallowKnight.gameplay.enemies.*;

import java.util.ArrayList;
import java.util.List;

public class GameModel {
    private KnightModel knightModel;
    private MapModel currentMap;

    // لیست دشمنان اضافه شد
    private List<EnemyModel> enemies;

    public GameModel() {

        currentMap = new MapModel("maps/crossroad map/map.tmx");

        float startX = currentMap.getKnightSpawn().x;
        float startY = currentMap.getKnightSpawn().y;

        knightModel = new KnightModel(startX, startY);

        // --- ساخت دشمنان بر اساس نقاط مشخص شده در نقشه ---
        enemies = new ArrayList<>();

        // ۱. ساخت تمام Crawlid ها
        for (Vector2 pos : currentMap.getCrawlidSpawns()) {
            enemies.add(new CrawlidModel(pos.x, pos.y));
        }

        // ۲. ساخت تمام Mosquito ها
        for (Vector2 pos : currentMap.getMosquitoSpawns()) {
            enemies.add(new MosquitoModel(pos.x, pos.y));
        }
        System.out.println("Enemies created: " + enemies.size());
    }

    public KnightModel getKnightModel() { return knightModel; }
    public MapModel getCurrentMap() { return currentMap; }

    // متد دسترسی به لیست دشمنان
    public List<EnemyModel> getEnemies() { return enemies; }
}
