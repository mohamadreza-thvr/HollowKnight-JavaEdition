package com.hallowKnight.gameplay.enemies;

public class CrawlidModel extends EnemyModel{

    private EnemyMovingState currentState = EnemyMovingState.WALK;
    private float stateTimer = 0f;

    public CrawlidModel(float x, float y) {
        super(x, y, 60, 40, 2);
        this.facingRight = false;
    }

    public EnemyMovingState getCurrentState() { return currentState; }
    public void setCurrentState(EnemyMovingState state) { this.currentState = state; }
    public float getStateTimer() { return stateTimer; }
    public void setStateTimer(float timer) { this.stateTimer = timer; }
}
